const CONFIG = {
  // Set to true for local development, false for production build
  IS_DEV: false,
  
  // Development URL
  DEV_URL: "http://localhost:5173",
  
  // Production URL
  PROD_URL: "https://steprec.onrender.com"
};
